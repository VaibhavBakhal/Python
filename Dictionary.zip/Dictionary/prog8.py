d={}
while True:
    print("1 add")
    print("2 update")
    print("3 display")
    print("4 delete")
    print("5 exit")
    
    print("enter the choice")
    choice=int(input())
    if choice==1:
        print("enter number of keys to be added")
        z=int(input())
        for i in range(z):
            a=int(input("key"))
            b=input("value")
            d[a]=b
    elif choice==2:
        z=int(input("enter key to update "))
        c=z
        a=(input("enter key value to be changed"))
        #d[c]=d.pop(z)
        d.update({z:a})
    elif choice==3:
        print(d)
    elif choice==4:
        z=int(input("enter key to delete"))
        d.pop(z)
    elif choice==5:
        break
    else: 
        print("enter a valid choice")

        
            
        
               
