a=input("enter number of keys key ")
a=int(a)
d={}
for i in range(a):
    b=int(input("enter key"))
    c=int(input("enter value"))
    
    d[b]=c
print(d)
