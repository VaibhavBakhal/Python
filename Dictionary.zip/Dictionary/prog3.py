d={x:x*x*x for x in range(1,11)}
print(d)
