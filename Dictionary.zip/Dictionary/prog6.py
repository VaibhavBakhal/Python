d={"name":"vaibhav","xyz":"shri","jhd":"ddg"}
d["dog"]=d.pop("jhd")
print(d)