d={1:5,6:55,7:88}
a=input("enter the key to be removed ")
a=int(a)
d.pop(a)
print(d)