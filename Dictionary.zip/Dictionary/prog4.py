d={10:5,2:5,6:4}
mul=1
for i in d.values():
    mul=mul*i
print(mul)