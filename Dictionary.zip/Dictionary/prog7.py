l1=[55,44,56,64]
l2=[2,6,4,7]
d={}
d=dict(zip(l1,l2))
print(d)