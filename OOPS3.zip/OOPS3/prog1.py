class BankAccount:
    def __init__(self,name,bankaccno,mob,balance):
        self.name=name
        self.bankaccno=int(bankaccno)
        self.__mob=int(mob)
        self.__balance=int(balance)
    def Display(self):
        print("name= ",self.name," bankaccno=",self.bankaccno)
   
    
   
b=BankAccount("vai", 45, 54968756, 43000)

b.Display()