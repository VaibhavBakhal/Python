lst=input("enter number of elements in list")
lst=int(lst)
l=[]
for i in range(lst):
    x=input()
    x=int(x)
    l.append(x)

a=list(map(lambda a:(a*a,a**3),l))
print(a)
#b=list(map(lambda a:a**3,l))
#print(b)
    