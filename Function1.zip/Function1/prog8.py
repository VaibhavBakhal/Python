lst=[(x,x*x) for x in range(1,31)]
print(lst)