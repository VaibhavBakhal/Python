b=lambda a:a+15
print(b(5))

c=lambda x,y:x*y
print(c())