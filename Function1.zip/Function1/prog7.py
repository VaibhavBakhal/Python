def unique(m):
    lst=[]
    for i in m:
        if i not in lst:
            lst.append(i)
    print(lst)               
    
unique([1,2,3,4,2,1,5,8])    
        
        
    