def fun1(name,*a):
    print(name)
    print(a)
fun1("abc","xyz",55)