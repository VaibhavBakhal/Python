def square(side):
    a=side*side
    print(a)
    
square(5)
sqr=square(55)

    