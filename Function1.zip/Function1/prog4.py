def Employee(name,salary=9000):
    print(name,salary)
Employee("shri",1000)
Employee("xyz")
