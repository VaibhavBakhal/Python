def square(a):
    return a*a
lst=[1,5,4,7,8,9,9,4]
l2=list(map(square,lst))
print(l2)
    