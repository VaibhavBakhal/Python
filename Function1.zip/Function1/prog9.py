l1=['a','b','c']
l2=["abc","xyz","aaa"]
l3=set(zip(l1,l2))
print(l3)