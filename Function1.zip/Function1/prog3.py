def cal(a,b):
    return a+b,a-b

print(cal(5,4))