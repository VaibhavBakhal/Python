def demo(name,age):
    print("Name=",name)
    print("age=",age)

demo("shri",25)

    