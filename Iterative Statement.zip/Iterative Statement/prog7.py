a=input("enter a number")
a=int(a)
sum=0
for i in range(a+1):
    sum=sum+i
print(sum)
