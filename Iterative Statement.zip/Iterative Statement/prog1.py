a=input("enter a number")
a=int(a)
rev=0
while a!=0:
    mod=a%10
    rev= rev*10 + mod
    a=a//10
print(rev)
