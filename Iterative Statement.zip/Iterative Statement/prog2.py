a = input("Enter a number")
a = int(a)
b= 0
while a!=0 :
    mod = a%10
    b= b+ mod
    a= a//10
print(b)
