start=input("enter start value")
start=int(start)
stop=input("enter stop value")
stop=int(stop)
for i in range(start,stop+1):
    if(i%2 !=0):
        print(i)
    
