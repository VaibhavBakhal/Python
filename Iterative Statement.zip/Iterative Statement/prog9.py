a=input("enter name")
for i in a:
    print(i,end=" ")
