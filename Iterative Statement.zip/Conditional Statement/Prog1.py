a=input("enter the first number")
b=input("enter second number")
c=input("enter third number")
a,b,c=c,b,a
print(a,b,c)
