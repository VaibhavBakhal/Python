a= input("Enter ")
a = int(a)
a= a/2.54
b= a/12
c= a%12
#b = a/30.48
#d= a%30.48
#c= (d/2.54)
print("conversion of CM to feet and incles is ",b, "feet",c, "inches")
