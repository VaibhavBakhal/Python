a,b,c= input("Enter 3 numbers").split()
a= int(a)
b= int(b)
c= int(c)
if a>b and a>c :
    print("a is largest")
elif b>a and b>c :
    print("b is largest")
elif c>a and c>b :
    print("c is largest")
elif a==b==c :
    print("all number are same")
elif a==b or b==c or c==a :
    print("Two numbers are same")

else  :
    print("Enter a valid input")
