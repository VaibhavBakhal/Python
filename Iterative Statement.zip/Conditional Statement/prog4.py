a=input(" enter a number")
b=a+a
c=a+a+a
a=int(a)
b=int(b)
c=int(c)
x=(a+b+c)
print( x)
print(a,b,c)
