a= input("Enter celcious")
a = int(a)
a= (a*(9/5))+32
print("Conversion of c to f is ",a)
