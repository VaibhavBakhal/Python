a,b,c,d,e=input("enter marks of 5 subjects").split()
a=int(a)
b=int(b)
c=int(c)
d=int(d)
e=int(e)
x=(a+b+c+d+e)/5
if x>50 and x<=70 :
    print("Second Class")
elif x>70 and x<=90 :
    print("First class")
elif x>90 and x<=100 :
    print("distinction")
else :
    print("fail")
