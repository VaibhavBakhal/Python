a=input("enter  number")
a= int(a)
if a > 0 : 
    print("number is positive")
else:
    print("number is negative")
