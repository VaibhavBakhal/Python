print(dir(__builtins__))
