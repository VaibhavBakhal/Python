if 4>3:print("Hello")

Hello
a=5
print("Positive") if a>0 else print("Negative")
Positive
a=-3
print("Positive") if a>0 else print("Negative")
Negative
