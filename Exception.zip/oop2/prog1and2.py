class person:
    def __init__(self,pid,pname,email,mob):
        self.pid=int(pid)
        self.pname=pname
        self.email=email
        self.mob=int(mob)
        
    def Display(self):
        print("person id =",self.pid,"name= ",self.pname,"email= ",self.email,"mob=",self.mob)

class emp(person):
    def __init__(self,pid,pname,email,mob,dept,desg,sal):
        super().__init__(pid, pname, email, mob)
        self.dept=dept
        self.desg=desg
        self.sal=int(sal)
        
    def setsal(self,salary):
       self.salary

    def getsal(self):
        return self.salary
    def calnetsal(self):
        netsal=self.sal+(self.sal*(5/100))
        return netsal
    def Display(self):
        super().Display()
        print("dept=",self.dept," desg=",self.desg," salary =",self.sal)
        
class member(person):
    def __init__(self, pid, pname, email, mob,membertype,amtpaid):
        super().__init__(pid, pname, email, mob)
        self.membertype=membertype
        self.amtpaid=int(amtpaid)
    def setamtpaid(self,amt):
        self.amtpaid=amt
    def getamtpaid(self):
        return self.amtpaid
    def Display(self):
        super().Display()
        print("id=",self.pid," name=",self.pname," email=",self.email," mob=",self.mob," membertype",self.membertype," amtpaid=",self.amtpaid)
               
        
        
        
p=person(1,"vai","vai@gmai",96745493853)
p.Display()
e=emp(2,"shu","shu@gmail",564698353,"sci","Assist",50000)
e.Display()

print(e.calnetsal())      
m=member(1, "shri", "shr@gmail", 584848484, "elite", 532000)
m.Display()
m.setamtpaid(20000)
print(m.getamtpaid())
        
        
        