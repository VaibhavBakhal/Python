try:
    i=int(input("enter 1st no"))
    j=int(input("enter 2nd number"))
    c=i/j
except(ValueError,ZeroDivisionError)as e:
    print("error occrued",e)