while(1):
    try:
        a=int(input("enter age"))
        b=float(input("enter height"))   
        c=float(input("enter weight   "))
        while(1):
            try:
               d=input("enter name ")
               f=input("enter surname")
               if (d.isdigit() or f.isdigit()):
                   raise Exception("Enter valid name and surname")
            except Exception as e:
               print("dont enter digits ",e)
            else:
                break

    except Exception as e:
        print("enter correct input",e)
    else:
        print("you have entered correct detils")
        print("name=",a," hight=",b," weight=",c," name=",d," surmane=",f)
        break    