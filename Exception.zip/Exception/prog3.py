def printlistelement(lst,index):
    try:
        if len(lst)<index:
            raise Exception("index out of range")
        elif(len(lst)>index):
            raise Exception("length of list is greater")
            
        
    except Exception:
        print("length of list is smaller than index")
    else:
        print("corrrect")

l1=[10,20,30,40,50,70,80]    
printlistelement(l1,10)

