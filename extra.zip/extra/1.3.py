# -*- coding: utf-8 -*-
"""
1. Write a program to input line(s) of text from the user
until enter is pressed. Count the total number of
characters in the text (including white spaces),total
number of alphabets, total number of digits, total
number of special symbols and total number of
words in the given text. (Assume that each word is
separated by one space).
"""
s=input()
print(s)
a=d=ss=w=c=0
for i in s:
    if i.isdigit():
        d+=1
    elif i.isalpha():
        a+=1
    elif i!=" ":
        ss+=1
l=s.split()
w=len(l)  
for i in s:
    c+=1


print(a,d,ss,w,c)