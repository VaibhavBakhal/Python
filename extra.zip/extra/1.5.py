# -*- coding: utf-8 -*-
"""
2. Write a user defined function to convert a string
with more than one word into title case string where
string is passed as parameter. (Title case means
that the first letter of each word is capitalised)
"""
def fun1(s):
    return s.title()

s=input()
print(fun1(s))