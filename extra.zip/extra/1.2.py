# -*- coding: utf-8 -*-
"""
2. Consider the following string myAddress:
 myAddress = "WZ-1,New Ganga Nagar,New Delhi"
 What will be the output of following string operations :
i. print(myAddress.lower())
ii. print(myAddress.upper())
iii. print(myAddress.count('New'))
iv. print(myAddress.find('New'))
v. print(myAddress.rfind('New'))
vi. print(myAddress.split(','))
vii. print(myAddress.split(' '))
viii. print(myAddress.replace('New','Old'))
ix. print(myAddress.partition(','))
x. print(myAddress.index('Agra'))
"""

myAddress = "WZ-1,New Ganga Nagar,New Delhi"
print(myAddress.lower())
print(myAddress.upper())
print(myAddress.count('New'))
print(myAddress.find('vai'))
print(myAddress.rfind('New'))
print(myAddress.split(','))
print(myAddress.split(' '))
print(myAddress.replace('New','Old'))
print(myAddress.partition(','))
print(myAddress.index('New'))