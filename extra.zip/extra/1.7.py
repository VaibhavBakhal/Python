# -*- coding: utf-8 -*-
"""
Input a string having some digits. Write a function
to return the sum of digits present in this string.
"""
s=input()
sum=0
for i in s:
    if i.isdigit():
         sum+=int(i)   
print(sum)
