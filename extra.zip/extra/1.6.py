# -*- coding: utf-8 -*-
"""
3. Write a function deleteChar() which takes two
parameters one is a string and other is a character.
The function should create a new string after
deleting all occurrences of the character from the
string and return the new string.
"""
def deleteChar(s,i):
    ns=""
    for j in s:
        if j!=i:
            ns=ns+j
    return ns
            
s="vaibhav"
i="a"
print(deleteChar(s,i))