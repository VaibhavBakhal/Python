def even(a):
    return a%2==0

def positive(a):
    return a>0

def negative(a):
    return a<0