import sys
a=sys.argv
print(a)
