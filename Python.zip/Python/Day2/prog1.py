print("Welcome")
no=int(input("Enter No"))


if no>0:
    print("No is Positive")
    print("Hi I am in if")
else:
    print("No is Negative")

print("Execution completed")




