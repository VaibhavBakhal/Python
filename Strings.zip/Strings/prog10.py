a=input("enter a string")
b=input("enter a character")
if a[:1]==b:
    print("yes")
else:
    print("no")
