a= input("Enter a string")
b=""
for i in a :
    b=i+b
if a==b:
    print("palindrome")
else :
    print("Not palindrome")
print(b)