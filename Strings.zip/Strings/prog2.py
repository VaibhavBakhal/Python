a=input("enter string")
b=input("enter the index ")
b=int(b)
print(a[:b-1]+a[b:])