a=input("Enter a string")
count=0
c= ""
for i in a:
    count+=1
if count<2:
    print(c)
else:
    print(a[:2]+a[-2:])