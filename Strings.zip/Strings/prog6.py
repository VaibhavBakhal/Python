a=input("enter a string")
print(a[1: :2])