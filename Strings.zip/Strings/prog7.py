a= input("Enter a string")
u=0
l=0
for i in a:
    if i.isupper():
        u+=1
    if i.islower():
        l+=1
        
print("Upper charaters=",u,"Lower charaters",l)
