# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 17:11:14 2022

@author: admin
"""

n=input()
n=int(n)
count=0
for i in range(n):
    line = str(input())
    for i in line:
        if i=='1' or i=='2' or i=='3' or i=='4' or i=='5' or i=='6' or i=='7' or i=='8' or i=='9' or i:
            count= count+1
    if count==10:
        if  line[ :1]=='9' or line[ :1]=='6' or  line[ :1]=='8' or line[ :1]=='7' :
                print("YES")
                count=0
        else:
                print("NO")
                count=0
    else:
            print("No")
            count=0
       