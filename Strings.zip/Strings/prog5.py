a=input("enter string")
count=0
for i in a:
    count=count+1
    print(i)
print(count)