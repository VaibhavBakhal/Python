a= str(input("Enter a string"))
print(a.replace(' ','-'))
