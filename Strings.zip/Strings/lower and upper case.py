def swap_case(s):
    D="abcdefghijklmnopqrstuvwxyz"
    c=""
    for i in s:
        if i in D:
            c= c + i.upper()
        else:
            c=c + i.lower()
    return c

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)