
a=(input("enter a string"))
print(a.replace('a',''))
    
