class student:
    def __init__(self,rollno,name,course,marks):
        self.rollno=rollno
        self.name=name
        self.course=course
        self.marks=dict(marks)
     
    
    def __str__(self):
        return f'rollno={self.rollno},name={self.name},course={self.course},marks={self.marks}'
    
while True:
    print("1 accept student data")
    print("2 print studnet data for given id ")
    print("3 student who has failed in any subject")
    print("4 display data")
    print("enter your choice")
    i=int(input())
    lst=[]
    if i==1:
        print("enter no of students")
        j=int(input())
        for i in range(j):
            print("enter rollno,name,course,marks")
            a=int(input("rollno"))
            b=input("name")
            c=input("course")
            d=d.update({input("subject"):int(input("Marks"))})
            s=student(a,b,c,d)
            lst.append(s)
    elif i==4:
        for i in lst:
            print(i)
    elif i==2:
        
            
            
            
            
        

        
            
        
    
        
        
        
        
        