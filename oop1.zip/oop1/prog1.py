class power:
    def __init__(self,x,n):
        self.x=x
        self.n=n
        
    def __del__(self):
        print("dec")
    def __str__(self):
        return f'number={self.x},power={self.n}'

def pow(e):
    print(e.x**e.n)
    
    
l=power(5,2)
pow(l)
     
        