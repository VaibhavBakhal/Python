class reverse:
    def __init__(self,s):
        self.s=s
    
    def __str__(self):
        return f'string={self.s}'
   
def rev(a):
    m=""
    b=list(a.s.split())
    b.reverse()
    m=','.join(b)
    print(m) 

a=reverse("i am a boy")
rev(a)        
        