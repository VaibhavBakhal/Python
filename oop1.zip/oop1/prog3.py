class prin:
    def __init__(self, a):
        self.a=a
    def setstring(self,b):
         self.b=b
    def getstring(self):
        return self.b.upper() 
    def __str__(self):
        return f'a={self.a},setstring={self.b}'
c=prin("aa")
c.setstring("abcvd")
print(c.getstring())
    

