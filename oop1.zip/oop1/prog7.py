class time:
    def __init__(self,hh=0,mm=0):
        self.hh=hh
        self.mm=mm
    
    def display(self):
        print("Hour",self.hh,"Min",self.mm)
def totalmin(t1):
    print("total min= ",(t1.hh*60)+t1.mm)
def addtime(t1,t2):
    t3=time()
    t3.hh=t1.hh+t2.hh
    t3.mm=t1.mm+t2.mm
    if t3.mm>=60:
        t3.hh=t3.hh+(t3.mm//60)
        t3.mm=t3.mm%60
    print("Hour=",t3.hh,"min=",t3.mm)
a=time(2,30)
b=time(1,45)
a.display()
b.display()
addtime(a,b)
totalmin(a)
