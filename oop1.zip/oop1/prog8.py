class dealer:
    def __init__(self,id,name,mob,address):
        self.id=id
        self.name=name
        self.mob=int(mob)
        self.address=address
    def __str__(self):
        return f'id={self.id},name={self.name},mob={self.mob},address={self.address}'
def punedel(l):
    m=[]
    for i in l:
        if i.address=='pune':
            m.append(i)
    for i in m:
        print(i)
def mobpal(l):
    m=[]
    for i in l:
        c=str(i.mob)
        if str(i.mob) == c[: :-1]:
            m.append(i)
    for i in m:
        print(i)

d1=dealer(1,"vai",1234567890,"pune")
d2=dealer(2,"shr",123454321,"pune")
d3=dealer(3,"shu",111111111,"mumbai")
d4=dealer(4,"bhu",121,"nakshik")
d5=dealer(5,"kri",12321,"pune")
l=[d1,d2,d3,d4,d5]
punedel(l)
print("---------------------------------")
mobpal(l)

    