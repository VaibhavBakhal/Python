class student:
    def __init__(self,name,rollno):
        self.name=name
        self.rollno=rollno
        
    
    
    def setage(self,age):
        self.age=age
    def setmarks(self,marks):
        self.marks=marks
    def display(self):
        print(self.age,self.marks)
    def __str__(self):
        return f'name={self.name},rollno={self.rollno}'                        
a=student("shri",55)
print(a) 
a.setage(51)
marks=[5,22,100]
a.setmarks(marks)      
print(a)
a.display()
        
        