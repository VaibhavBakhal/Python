class time:
    def __init__(self,hh,mm):
        self.hh=hh
        self.mm=mm
        
    def __str__(self):
        return f'hour={self.hh},{self.mm}'
    
    def addtime(t1,t2):
        t3=time(0,0)
        t3.hh=t1.hh+t2.hh
        t3.mm=t1.mm+t2.mm
        if(t3.mm>=60):
            t3.hh=t3.mm//60
            t3.mm=t3.mm%60
        print(t3.hh,t3.mm)
        
    def minute(t5):
        
        m=(t5.hh)*60
        m+=t5.mm
        print(m)
        
a=time(5,40)
b=time(4,10)

time.addtime(a,b)
time.minute(a)
        
