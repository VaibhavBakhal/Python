class rect:
    def __init__(self,l,b):
        self.l=l
        self.b=b
    def __str__(self):
        return f'length={self.l}, breadth={self.b}'
    
def rectangle(a):
     area=a.l*a.b
     print(area)

x=rect(5,5)
rectangle(x)        
    