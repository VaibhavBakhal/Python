class tempr:
        def __init__(self,c,f):
            self.c=float(c)
            self.f=float(f)
        def __str__(self):
            return f'celcius={self.c}, farhenit={self.f}'
        
def con(x):
    
    farher=(x.c*1.8)+32
    print(farher)
    cel=(x.f-32)*(5/9)
    print(cel)

x=tempr(50,40)
con(x)    
    

    
        